export default  {
    icStatus: require('../assets/images/ic_camera.png'),
    icCalls: require('../assets/images/ic_phone.png'),
    icCamera: require('../assets/images/ic_camera.png'),
    icChats: require('../assets/images/ic_chat.png'),
    icSettings: require('../assets/images/ic_setting.png'),
    icLogo: require('../assets/images/logo.png'),
    icForward: require('../assets/images/ic_forward.png'),
    icBack: require('../assets/images/ic_back.png'),
    icEdit: require('../assets/images/ic_edit.png'),
    icGroup: require('../assets/images/ic_group.png'),
    icVideo: require('../assets/images/ic_video.png'),
    icPlus: require('../assets/images/ic_plus.png'),
    icBigLight: require("../assets/images/ic_lightbg.png")
}