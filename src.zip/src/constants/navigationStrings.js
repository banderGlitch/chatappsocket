export default {
    TAB_ROUTES:"tabRoutes",
    STATUS:"status",
    CALLS:"calls",
    CAMERA:"camera",
    CHATS:"chats",
    SETTINGS:"settings",
    TERMS_CONDITION:"termsCondition",
    OTP_VERIFICATION:"otpVerification",
    PHONE_NUMBER:"phoneNumber",
    EDIT_PROFILE:"editProfile",
    USERS:"users",
}