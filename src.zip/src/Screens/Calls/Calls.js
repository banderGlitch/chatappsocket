import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Calls() {
  return (
    <View>
      <Text>Calls</Text>
    </View>
  )
}

const styles = StyleSheet.create({})