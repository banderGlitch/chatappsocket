export default {
    themeColor: '#4B5F44',
    white: '#ffffff',
    black: '#111111',
    blue: 'blue',
    lightBlue: '#0096FF',
    grey: 'grey'
}