export default {
    regular: 'Comfortaa',
    bold: 'Comfortaa-Bold',
    blackFont: 'CircularStd-Black',
    thin:  'Comfortaa-Thin',
}