import * as  auth from './auth';

export default {
    ...auth
}
